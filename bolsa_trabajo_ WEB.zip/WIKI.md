# Bolsa de Trabajo - Wiki (resumen)
Incluye HU (35), RF y RNF. Revisa backend/README.md para endpoints y uso.
