# Bolsa de Trabajo - Proyecto completo

Generado: 2025-11-19T20:03:44.305275Z

Estructura:
- backend/  (Spring Boot + MongoDB)
- Interfaz/ (HTML + CSS + JS)

Sigue los README dentro de cada carpeta para ejecutar localmente.
