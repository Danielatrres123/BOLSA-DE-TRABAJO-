const API = "http://localhost:8080/api";

async function loadOfertas(){
  const res = await fetch(API + "/ofertas");
  const data = await res.json();
  const container = document.getElementById("ofertas");
  container.innerHTML = "";
  data.forEach(o => {
    const div = document.createElement("div");
    div.className = "job";
    div.innerHTML = `<h3>${o.titulo}</h3>
      <p>${o.descripcion || ''}</p>
      <p><strong>Vacantes:</strong> ${o.vacantes}</p>
      <p><small>Empresa ID: ${o.empresaId}</small></p>
      <p><button onclick="postular('${o.id}')">Postular</button></p>`;
    container.appendChild(div);
  });
}

async function crearOferta(){
  const empresaId = document.getElementById("empresaId").value;
  const titulo = document.getElementById("titulo").value;
  const descripcion = document.getElementById("descripcion").value;
  const vacantes = Number(document.getElementById("vacantes").value || 1);

  const res = await fetch(API + "/ofertas", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({empresaId, titulo, descripcion, vacantes})
  });
  if(res.ok){
    document.getElementById("msg").innerText = "Oferta publicada";
    loadOfertas();
  } else {
    const txt = await res.text();
    document.getElementById("msg").innerText = "Error: " + txt;
  }
}

async function postular(ofertaId){
  const usuarioId = prompt("Ingresa tu ID de usuario (crear con POST /api/usuarios)");
  if(!usuarioId) return;
  const res = await fetch(API + "/postulaciones", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({usuarioId, ofertaId})
  });
  if(res.ok) alert("Postulación enviada");
  else {
    const txt = await res.text();
    alert("Error: " + txt);
  }
}

document.getElementById("btn-post").addEventListener("click", crearOferta);
document.getElementById("btn-refresh").addEventListener("click", loadOfertas);

// initial load
loadOfertas();
