package com.bolsatrabajo.init;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;
import com.bolsatrabajo.repository.EmpresaRepository;
import com.bolsatrabajo.repository.OfertaRepository;
import com.bolsatrabajo.model.Empresa;
import com.bolsatrabajo.model.Oferta;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final EmpresaRepository empresaRepo;
    private final OfertaRepository ofertaRepo;

    @Override
    public void run(String... args) throws Exception {
        if(empresaRepo.count() == 0){
            Empresa e1 = new Empresa(); e1.setNombre("Tech Solutions"); e1.setDescripcion("Empresa de software"); e1.setContacto("contacto@tech.com");
            Empresa e2 = new Empresa(); e2.setNombre("Creativo Agency"); e2.setDescripcion("Agencia creativa"); e2.setContacto("hola@creativo.com");
            empresaRepo.save(e1); empresaRepo.save(e2);

            Oferta o1 = new Oferta(); o1.setTitulo("Desarrollador Backend"); o1.setDescripcion("Java + Spring"); o1.setEmpresaId(e1.getId()); o1.setVacantes(2);
            Oferta o2 = new Oferta(); o2.setTitulo("Diseñador UX/UI"); o2.setDescripcion("Diseño de interfaces"); o2.setEmpresaId(e2.getId()); o2.setVacantes(1);
            ofertaRepo.save(o1); ofertaRepo.save(o2);
        }
    }
}
