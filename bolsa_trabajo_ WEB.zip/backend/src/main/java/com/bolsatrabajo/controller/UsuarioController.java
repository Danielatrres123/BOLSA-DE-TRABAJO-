package com.bolsatrabajo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.bolsatrabajo.service.UsuarioService;
import com.bolsatrabajo.model.Usuario;
import com.bolsatrabajo.dto.UsuarioCreateDto;
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {
    private final UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<Usuario> create(@Valid @RequestBody UsuarioCreateDto dto){
        return ResponseEntity.status(201).body(usuarioService.create(dto));
    }

    @GetMapping
    public List<Usuario> all(){ return usuarioService.all(); }
}
