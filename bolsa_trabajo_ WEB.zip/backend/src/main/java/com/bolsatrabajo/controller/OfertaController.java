package com.bolsatrabajo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.bolsatrabajo.service.OfertaService;
import com.bolsatrabajo.model.Oferta;
import com.bolsatrabajo.dto.OfertaCreateDto;
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/ofertas")
@RequiredArgsConstructor
public class OfertaController {
    private final OfertaService ofertaService;

    @PostMapping
    public ResponseEntity<Oferta> create(@Valid @RequestBody OfertaCreateDto dto){
        return ResponseEntity.status(201).body(ofertaService.create(dto));
    }

    @GetMapping
    public List<Oferta> active(){ return ofertaService.active(); }

    @GetMapping("/{id}")
    public ResponseEntity<Oferta> get(@PathVariable String id){
        return ofertaService.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Oferta> update(@PathVariable String id, @RequestBody Oferta o){
        return ResponseEntity.ok(ofertaService.update(id, o));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id){
        ofertaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
