package com.bolsatrabajo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.bolsatrabajo.service.EmpresaService;
import com.bolsatrabajo.model.Empresa;
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/empresas")
@RequiredArgsConstructor
public class EmpresaController {
    private final EmpresaService empresaService;

    @PostMapping
    public ResponseEntity<Empresa> create(@Valid @RequestBody Empresa e){
        return ResponseEntity.status(201).body(empresaService.create(e));
    }

    @GetMapping
    public List<Empresa> all(){ return empresaService.all(); }
}
