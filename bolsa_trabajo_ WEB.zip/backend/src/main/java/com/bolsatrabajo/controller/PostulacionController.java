package com.bolsatrabajo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.bolsatrabajo.service.PostulacionService;
import com.bolsatrabajo.dto.PostulacionCreateDto;
import com.bolsatrabajo.model.Postulacion;
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/postulaciones")
@RequiredArgsConstructor
public class PostulacionController {
    private final PostulacionService postulacionService;

    @PostMapping
    public ResponseEntity<Postulacion> create(@Valid @RequestBody PostulacionCreateDto dto){
        Postulacion p = new Postulacion();
        p.setUsuarioId(dto.getUsuarioId());
        p.setOfertaId(dto.getOfertaId());
        return ResponseEntity.status(201).body(postulacionService.create(p));
    }

    @GetMapping("/usuario/{usuarioId}")
    public List<Postulacion> byUsuario(@PathVariable String usuarioId){ return postulacionService.byUsuario(usuarioId); }

    @GetMapping("/oferta/{ofertaId}")
    public List<Postulacion> byOferta(@PathVariable String ofertaId){ return postulacionService.byOferta(ofertaId); }
}
