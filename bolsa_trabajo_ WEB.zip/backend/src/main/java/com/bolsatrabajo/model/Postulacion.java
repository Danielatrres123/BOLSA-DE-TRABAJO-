package com.bolsatrabajo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;
import java.time.LocalDateTime;
import jakarta.validation.constraints.NotBlank;

@Document(collection = "postulaciones")
@Data
public class Postulacion {
    @Id
    private String id;

    @NotBlank(message = "usuarioId requerido")
    private String usuarioId;

    @NotBlank(message = "ofertaId requerido")
    private String ofertaId;

    private LocalDateTime fecha = LocalDateTime.now();
    private String estado = "ENVIADA";
}
