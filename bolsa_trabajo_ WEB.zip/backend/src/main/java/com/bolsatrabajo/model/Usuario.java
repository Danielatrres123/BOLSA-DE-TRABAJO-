package com.bolsatrabajo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Document(collection = "usuarios")
@Data
public class Usuario {
    @Id
    private String id;

    @NotBlank(message = "El nombre es requerido")
    private String nombre;

    @Email(message = "Correo inválido")
    @NotBlank(message = "El correo es requerido")
    private String correo;

    @NotBlank(message = "La contraseña es requerida")
    private String passwordHash;
}
