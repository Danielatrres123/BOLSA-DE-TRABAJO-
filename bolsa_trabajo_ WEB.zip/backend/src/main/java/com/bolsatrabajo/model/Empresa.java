package com.bolsatrabajo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Document(collection = "empresas")
@Data
public class Empresa {
    @Id
    private String id;

    @NotBlank(message = "Nombre es requerido")
    private String nombre;

    private String descripcion;
    private String contacto;
}
