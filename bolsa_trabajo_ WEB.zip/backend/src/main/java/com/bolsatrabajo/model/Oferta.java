package com.bolsatrabajo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Document(collection = "ofertas")
@Data
public class Oferta {
    @Id
    private String id;

    @NotBlank(message = "Título es requerido")
    private String titulo;

    private String descripcion;

    @NotBlank(message = "empresaId es requerido")
    private String empresaId;

    @Min(value = 1, message = "Vacantes debe ser al menos 1")
    private int vacantes = 1;

    private boolean activa = true;
}
