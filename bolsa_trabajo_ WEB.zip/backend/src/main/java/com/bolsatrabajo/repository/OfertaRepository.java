package com.bolsatrabajo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.bolsatrabajo.model.Oferta;
import java.util.List;

public interface OfertaRepository extends MongoRepository<Oferta, String> {
    List<Oferta> findByActivaTrue();
    List<Oferta> findByEmpresaId(String empresaId);
}
