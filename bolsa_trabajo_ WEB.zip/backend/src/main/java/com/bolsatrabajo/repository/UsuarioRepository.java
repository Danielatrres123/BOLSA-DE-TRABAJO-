package com.bolsatrabajo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.bolsatrabajo.model.Usuario;
import java.util.Optional;

public interface UsuarioRepository extends MongoRepository<Usuario, String> {
    boolean existsByCorreo(String correo);
    Optional<Usuario> findByCorreo(String correo);
}
