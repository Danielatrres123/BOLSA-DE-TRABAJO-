package com.bolsatrabajo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.bolsatrabajo.model.Empresa;

public interface EmpresaRepository extends MongoRepository<Empresa, String> {
}
