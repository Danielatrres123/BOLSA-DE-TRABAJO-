package com.bolsatrabajo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.bolsatrabajo.model.Postulacion;
import java.util.List;

public interface PostulacionRepository extends MongoRepository<Postulacion, String> {
    List<Postulacion> findByUsuarioId(String usuarioId);
    List<Postulacion> findByOfertaId(String ofertaId);
}
