package com.bolsatrabajo.service;

import org.springframework.stereotype.Service;
import com.bolsatrabajo.repository.OfertaRepository;
import com.bolsatrabajo.model.Oferta;
import com.bolsatrabajo.dto.OfertaCreateDto;
import lombok.RequiredArgsConstructor;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OfertaService {
    private final OfertaRepository ofertaRepository;

    public Oferta create(OfertaCreateDto dto){
        Oferta o = new Oferta();
        o.setTitulo(dto.getTitulo());
        o.setDescripcion(dto.getDescripcion());
        o.setEmpresaId(dto.getEmpresaId());
        o.setVacantes(dto.getVacantes());
        o.setActiva(true);
        return ofertaRepository.save(o);
    }

    public List<Oferta> active(){ return ofertaRepository.findByActivaTrue(); }
    public Optional<Oferta> findById(String id){ return ofertaRepository.findById(id); }

    public Oferta update(String id, Oferta updated){
        Optional<Oferta> opt = ofertaRepository.findById(id);
        if(opt.isEmpty()) throw new IllegalArgumentException("Oferta no encontrada");
        Oferta o = opt.get();
        o.setTitulo(updated.getTitulo());
        o.setDescripcion(updated.getDescripcion());
        o.setVacantes(updated.getVacantes());
        o.setActiva(updated.isActiva());
        return ofertaRepository.save(o);
    }
    public void delete(String id){ ofertaRepository.deleteById(id); }
}
