package com.bolsatrabajo.service;

import org.springframework.stereotype.Service;
import com.bolsatrabajo.repository.PostulacionRepository;
import com.bolsatrabajo.repository.OfertaRepository;
import com.bolsatrabajo.repository.UsuarioRepository;
import com.bolsatrabajo.model.Postulacion;
import com.bolsatrabajo.model.Oferta;
import lombok.RequiredArgsConstructor;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PostulacionService {
    private final PostulacionRepository postulacionRepository;
    private final OfertaRepository ofertaRepository;
    private final UsuarioRepository usuarioRepository;

    public Postulacion create(Postulacion p){
        var oferta = ofertaRepository.findById(p.getOfertaId());
        if(oferta.isEmpty() || !oferta.get().isActiva()) throw new IllegalArgumentException("Oferta no disponible");
        if(!usuarioRepository.existsById(p.getUsuarioId())) throw new IllegalArgumentException("Usuario no encontrado");
        return postulacionRepository.save(p);
    }

    public List<Postulacion> byUsuario(String usuarioId){ return postulacionRepository.findByUsuarioId(usuarioId); }
    public List<Postulacion> byOferta(String ofertaId){ return postulacionRepository.findByOfertaId(ofertaId); }
}
