package com.bolsatrabajo.service;

import org.springframework.stereotype.Service;
import com.bolsatrabajo.repository.EmpresaRepository;
import com.bolsatrabajo.model.Empresa;
import lombok.RequiredArgsConstructor;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EmpresaService {
    private final EmpresaRepository empresaRepository;

    public Empresa create(Empresa e){ return empresaRepository.save(e); }
    public List<Empresa> all(){ return empresaRepository.findAll(); }
}
