package com.bolsatrabajo.service;

import org.springframework.stereotype.Service;
import com.bolsatrabajo.repository.UsuarioRepository;
import com.bolsatrabajo.model.Usuario;
import com.bolsatrabajo.dto.UsuarioCreateDto;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UsuarioService {
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public Usuario create(UsuarioCreateDto dto){
        if(usuarioRepository.existsByCorreo(dto.getCorreo())) throw new IllegalArgumentException("Correo ya registrado");
        Usuario u = new Usuario();
        u.setNombre(dto.getNombre());
        u.setCorreo(dto.getCorreo());
        u.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        return usuarioRepository.save(u);
    }

    public List<Usuario> all(){ return usuarioRepository.findAll(); }
}
