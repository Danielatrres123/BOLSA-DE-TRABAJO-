package com.bolsatrabajo.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OfertaCreateDto {
    @NotBlank
    private String titulo;
    private String descripcion;
    @NotBlank
    private String empresaId;
    @Min(1)
    private int vacantes = 1;
}
