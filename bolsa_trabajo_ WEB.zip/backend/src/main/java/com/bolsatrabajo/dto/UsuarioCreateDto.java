package com.bolsatrabajo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UsuarioCreateDto {
    @NotBlank
    private String nombre;
    @Email
    @NotBlank
    private String correo;
    @NotBlank
    private String password;
}
