package com.bolsatrabajo.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PostulacionCreateDto {
    @NotBlank
    private String usuarioId;
    @NotBlank
    private String ofertaId;
}
